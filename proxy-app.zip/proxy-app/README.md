# Proxy Web CORS

Un proxy semplice per incorporare contenuti HTML da altri siti evitando le restrizioni CORS.

## Uso

1. Deploy su Render o Vercel.
2. Visita: `https://TUO-APP.render.com/proxy?url=https://www.tuttolomondo.it`
